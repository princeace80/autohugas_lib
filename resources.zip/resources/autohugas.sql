-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2016 at 11:33 AM
-- Server version: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `autohugas`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminid` int(15) NOT NULL,
  `adminname` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminid`, `adminname`, `username`, `password`, `status`) VALUES
(1, 'john', 'john', 'john', 1),
(2, 'loyd', 'loyd', 'loyd', 1),
(3, 'luis', 'luis', 'luis', 1),
(4, 'billy', 'billy', 'billy', 1);

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branchid` int(15) NOT NULL,
  `carwashid` int(15) NOT NULL,
  `address` varchar(50) NOT NULL,
  `longitude` float(15,12) NOT NULL,
  `latitude` float(15,12) NOT NULL,
  `paymentmethod` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branchid`, `carwashid`, `address`, `longitude`, `latitude`, `paymentmethod`) VALUES
(1, 1, 'A.S fortuna , Mandaue', 123.926040649414, 10.339392662048, 'online'),
(2, 2, 'F Llamas St, Tisa,Cebu', 123.869804382324, 10.300521850586, 'walk in'),
(3, 3, 'Vicente Rama Avenue, Cebu City', 123.886375427246, 10.310128211975, 'online'),
(4, 4, 'Kaohsiung St, Cebu City,', 123.920341491699, 10.313126564026, 'online');

-- --------------------------------------------------------

--
-- Table structure for table `carwash`
--

CREATE TABLE `carwash` (
  `carwashid` int(15) NOT NULL,
  `carwashname` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` text NOT NULL,
  `address` varchar(150) NOT NULL,
  `contactno` varchar(25) NOT NULL,
  `adminid` int(15) NOT NULL,
  `longitude` varchar(100) NOT NULL,
  `latitude` varchar(100) NOT NULL,
  `emailadd` varchar(25) NOT NULL,
  `subscriptionid` int(15) NOT NULL,
  `proprietor` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `carwash`
--

INSERT INTO `carwash` (`carwashid`, `carwashname`, `username`, `password`, `address`, `contactno`, `adminid`, `longitude`, `latitude`, `emailadd`, `subscriptionid`, `proprietor`) VALUES
(1, 'Niceday Carwash', 'user', 'pass', 'North Reclamation Area, Cebu City, Cebu, Philippines', '(032) 509-2985', 1, '123.92016805708408', '10.313145966664115', 'azumi_19210@yahoo.com', 2, 'Azumi'),
(2, 'Wingees Carwash', 'wingees', 'pass', 'Tisa National High School, Cebu City, Cebu, Philippines', '+639173085549', 1, '123.86968553066254', '10.300542446509587', 'wingess@gmail.com', 1, 'wingees');

-- --------------------------------------------------------

--
-- Table structure for table `customerpayment`
--

CREATE TABLE `customerpayment` (
  `paymentid` int(15) NOT NULL,
  `paymentdate` datetime NOT NULL,
  `amount` int(15) NOT NULL,
  `paymentmethod` varchar(15) NOT NULL,
  `customerid` int(15) NOT NULL,
  `reservationid` int(15) NOT NULL,
  `paid` bit(1) NOT NULL COMMENT '0 - unpaid and 1 - paid'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customerpayment`
--

INSERT INTO `customerpayment` (`paymentid`, `paymentdate`, `amount`, `paymentmethod`, `customerid`, `reservationid`, `paid`) VALUES
(5, '2016-02-07 00:00:00', 230, 'walk in', 34, 25, b'0');

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `reservationid` int(15) NOT NULL,
  `carwashid` int(15) NOT NULL,
  `paymentdate` datetime NOT NULL,
  `customerid` int(15) NOT NULL,
  `totalamount` int(15) NOT NULL,
  `paymentmethod` varchar(15) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`reservationid`, `carwashid`, `paymentdate`, `customerid`, `totalamount`, `paymentmethod`, `status`) VALUES
(24, 2, '2016-02-06 00:00:00', 27, 550, 'cash', 1),
(25, 3, '2016-02-01 00:00:00', 28, 320, 'cash', 1);

-- --------------------------------------------------------

--
-- Table structure for table `joborder`
--

CREATE TABLE `joborder` (
  `joborderid` int(15) NOT NULL,
  `customerid` int(15) NOT NULL,
  `amountdue` int(15) NOT NULL,
  `paymentid` int(15) NOT NULL,
  `reservationid` int(15) NOT NULL,
  `vehicleid` int(15) NOT NULL,
  `serviceid` int(15) NOT NULL,
  `staffid` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `joborder`
--

INSERT INTO `joborder` (`joborderid`, `customerid`, `amountdue`, `paymentid`, `reservationid`, `vehicleid`, `serviceid`, `staffid`) VALUES
(15, 27, 550, 12, 21, 10, 11, 13),
(16, 22, 600, 22, 14, 15, 11, 8);

-- --------------------------------------------------------

--
-- Table structure for table `joborderdetails`
--

CREATE TABLE `joborderdetails` (
  `joborderdetailsid` int(15) NOT NULL,
  `serviceid` int(15) NOT NULL,
  `joborderid` int(15) NOT NULL,
  `staffid` int(15) NOT NULL,
  `vehicleid` int(15) NOT NULL,
  `status` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `joborderdetails`
--

INSERT INTO `joborderdetails` (`joborderdetailsid`, `serviceid`, `joborderid`, `staffid`, `vehicleid`, `status`) VALUES
(12, 23, 11, 10, 21, '1'),
(13, 24, 12, 11, 22, '1');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `paymentid` int(15) NOT NULL,
  `paymentdate` datetime NOT NULL,
  `amount` int(15) NOT NULL,
  `paymentmethod` varchar(15) NOT NULL,
  `carwashid` int(15) NOT NULL,
  `subscriptionid` int(15) NOT NULL,
  `billingperiod` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`paymentid`, `paymentdate`, `amount`, `paymentmethod`, `carwashid`, `subscriptionid`, `billingperiod`) VALUES
(1, '2016-02-01 00:00:00', 500, 'walk-in', 1, 1, '2016-03-01 00:00:00'),
(2, '2016-02-02 00:00:00', 1500, 'online', 2, 2, '2016-08-02 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `reservation_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `carwashid` int(11) NOT NULL,
  `date_reserve` date NOT NULL,
  `payment_method` bit(1) NOT NULL COMMENT '1- paypal and 0 - cash',
  `paid` bit(1) NOT NULL COMMENT '1- paid and 0 - not paid',
  `reserve_service_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reserve_services`
--

CREATE TABLE `reserve_services` (
  `reserve_services_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `serviceid` int(15) NOT NULL,
  `carwashid` int(15) NOT NULL,
  `servicerate` int(25) NOT NULL,
  `servicename` varchar(25) NOT NULL,
  `serviceduration` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`serviceid`, `carwashid`, `servicerate`, `servicename`, `serviceduration`) VALUES
(1, 1, 100, 'body wash', '01:00:00'),
(2, 1, 200, 'vacuum', '00:30:00'),
(3, 1, 300, 'Detailing', '01:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staffid` int(15) NOT NULL,
  `stafffname` varchar(25) NOT NULL,
  `staffmname` varchar(25) NOT NULL,
  `stafflname` varchar(25) NOT NULL,
  `address` varchar(25) NOT NULL,
  `position` varchar(25) NOT NULL,
  `salarytype` varchar(25) NOT NULL,
  `salaryrate` varchar(25) NOT NULL,
  `branchid` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staffid`, `stafffname`, `staffmname`, `stafflname`, `address`, `position`, `salarytype`, `salaryrate`, `branchid`) VALUES
(1, 'paloma', 'de leon', 'dalisay', 'sanciangko', 'carwash girl', 'commission', '20% per service', 1),
(2, 'Marian', 'Rivera', 'Dantes', 'Leon Kilat', 'Cashier', 'monthly', '3000 a month', 2),
(3, 'charo', 'santos', 'concio', 'colon', 'manager', 'daily', 'minimum', 3);

-- --------------------------------------------------------

--
-- Table structure for table `subscription`
--

CREATE TABLE `subscription` (
  `subscriptionid` int(15) NOT NULL,
  `paymenttype` varchar(15) NOT NULL,
  `paymentdate` datetime NOT NULL,
  `paymentnotify` varchar(25) NOT NULL,
  `paymentid` int(15) NOT NULL,
  `paymentamount` int(15) NOT NULL,
  `subscriptionfee` int(15) NOT NULL,
  `subscriptionperiod` datetime NOT NULL,
  `subscriptionplanid` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subscription`
--

INSERT INTO `subscription` (`subscriptionid`, `paymenttype`, `paymentdate`, `paymentnotify`, `paymentid`, `paymentamount`, `subscriptionfee`, `subscriptionperiod`, `subscriptionplanid`) VALUES
(1, 'cash', '2016-02-01 00:00:00', '1', 1, 500, 500, '2016-02-29 00:00:00', 1),
(2, 'cash', '2016-02-02 00:00:00', '1', 2, 1500, 1500, '2016-03-01 00:00:00', 2);

-- --------------------------------------------------------

--
-- Table structure for table `subscriptionplan`
--

CREATE TABLE `subscriptionplan` (
  `subscriptionplanid` int(15) NOT NULL,
  `subscriptionname` varchar(25) NOT NULL,
  `price` varchar(25) NOT NULL,
  `description` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subscriptionplan`
--

INSERT INTO `subscriptionplan` (`subscriptionplanid`, `subscriptionname`, `price`, `description`) VALUES
(1, 'premium', '500', 'one month subscription with out advertise'),
(2, 'gold', '1500', 'six months subscription with advistise'),
(3, 'diamond', '2000', 'one year subscription with advertise');

-- --------------------------------------------------------

--
-- Table structure for table `superadmin`
--

CREATE TABLE `superadmin` (
  `sadminid` int(15) NOT NULL,
  `sadminusername` varchar(25) NOT NULL,
  `sadminpassword` varchar(25) NOT NULL,
  `sadminstatus` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `superadmin`
--

INSERT INTO `superadmin` (`sadminid`, `sadminusername`, `sadminpassword`, `sadminstatus`) VALUES
(1, 'joya', 'joya', 1),
(2, 'rhea', 'rhea', 1),
(3, 'honey', 'honey', 1),
(4, 'franz', 'franz', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `vehicleid` int(15) NOT NULL,
  `customerid` int(3) NOT NULL,
  `vehiclecolor` varchar(25) NOT NULL,
  `model` varchar(25) NOT NULL,
  `brand` varchar(25) NOT NULL,
  `vehicletype` varchar(25) NOT NULL,
  `plateNumber` varchar(15) NOT NULL,
  `registrationNumber` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`vehicleid`, `customerid`, `vehiclecolor`, `model`, `brand`, `vehicletype`, `plateNumber`, `registrationNumber`) VALUES
(2, 1, 'red', 'innova', 'toyota', 'suv', 'ABC123', '1245'),
(3, 1, 'white', 'hilux', 'toyota', 'pick up', 'ACP123478', '67898766'),
(6, 3, 'Blue', 'Toyota Vios', 'Toyota', 'Sedan', '123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `vehicleowner`
--

CREATE TABLE `vehicleowner` (
  `customerid` int(15) NOT NULL,
  `custfname` varchar(25) NOT NULL,
  `custmname` varchar(15) NOT NULL,
  `custlname` varchar(15) NOT NULL,
  `address` varchar(25) NOT NULL,
  `custcontactno` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `carwashid` int(15) NOT NULL,
  `emailadd` varchar(25) NOT NULL,
  `paymentmethod` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicleowner`
--

INSERT INTO `vehicleowner` (`customerid`, `custfname`, `custmname`, `custlname`, `address`, `custcontactno`, `username`, `password`, `carwashid`, `emailadd`, `paymentmethod`) VALUES
(1, 'ryan', 'm', 'sarno', 'address', '093431255', 'user', 'pass', 1, 'email@add.com', 'walk-in'),
(2, 'Maine', 'capili', 'Mendoza', 'bulacao', '123532', 'yayadub', 'yaya', 2, 'yaya@yahoo.com', 'walk-in'),
(3, 'alden', 'reyes', 'faulkerson', 'sambag 1', '43231', 'alden', 'alden', 3, 'alden@gmail.com', 'online'),
(4, 'fnme', 'mname', 'lname', 'asd', '213', 'user1', 'pass', 0, 'azumi_19210@yahoo.com', ''),
(5, 'joya', 'Toling', 'compz', 'looc lapu lapu city', '09326464610', 'joya', 'joya', 0, 'joya@gmail.com', ''),
(18, 'jojo', 'jojo', 'jojo', 'jojoj', 'abcdef', 'jojo', 'ojo', 0, 'asdasd', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminid`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`branchid`);

--
-- Indexes for table `carwash`
--
ALTER TABLE `carwash`
  ADD PRIMARY KEY (`carwashid`);

--
-- Indexes for table `customerpayment`
--
ALTER TABLE `customerpayment`
  ADD PRIMARY KEY (`paymentid`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`reservationid`);

--
-- Indexes for table `joborder`
--
ALTER TABLE `joborder`
  ADD PRIMARY KEY (`joborderid`);

--
-- Indexes for table `joborderdetails`
--
ALTER TABLE `joborderdetails`
  ADD PRIMARY KEY (`joborderdetailsid`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`paymentid`);

--
-- Indexes for table `reserve_services`
--
ALTER TABLE `reserve_services`
  ADD PRIMARY KEY (`reserve_services_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`serviceid`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staffid`);

--
-- Indexes for table `subscription`
--
ALTER TABLE `subscription`
  ADD PRIMARY KEY (`subscriptionid`);

--
-- Indexes for table `subscriptionplan`
--
ALTER TABLE `subscriptionplan`
  ADD PRIMARY KEY (`subscriptionplanid`);

--
-- Indexes for table `superadmin`
--
ALTER TABLE `superadmin`
  ADD PRIMARY KEY (`sadminid`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`vehicleid`);

--
-- Indexes for table `vehicleowner`
--
ALTER TABLE `vehicleowner`
  ADD PRIMARY KEY (`customerid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `branchid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `carwash`
--
ALTER TABLE `carwash`
  MODIFY `carwashid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `customerpayment`
--
ALTER TABLE `customerpayment`
  MODIFY `paymentid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `job`
--
ALTER TABLE `job`
  MODIFY `reservationid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `joborder`
--
ALTER TABLE `joborder`
  MODIFY `joborderid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `joborderdetails`
--
ALTER TABLE `joborderdetails`
  MODIFY `joborderdetailsid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `paymentid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `reserve_services`
--
ALTER TABLE `reserve_services`
  MODIFY `reserve_services_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `serviceid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staffid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `subscription`
--
ALTER TABLE `subscription`
  MODIFY `subscriptionid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `subscriptionplan`
--
ALTER TABLE `subscriptionplan`
  MODIFY `subscriptionplanid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `superadmin`
--
ALTER TABLE `superadmin`
  MODIFY `sadminid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `vehicleid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `vehicleowner`
--
ALTER TABLE `vehicleowner`
  MODIFY `customerid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
